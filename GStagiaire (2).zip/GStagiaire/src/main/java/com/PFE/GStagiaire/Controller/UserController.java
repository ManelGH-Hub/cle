package com.PFE.GStagiaire.Controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.rest.webmvc.ResourceNotFoundException;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import org.springframework.web.bind.annotation.*;

import com.PFE.GStagiaire.Repository.UserRepository;
import com.PFE.GStagiaire.Service.ImplementationUser;
import com.PFE.GStagiaire.Entity.User;
import com.PFE.GStagiaire.Entity.RoleType;


@RestController
@RequestMapping("/api/users")
public class UserController {
    @Autowired
    private ImplementationUser userService;

    @GetMapping
    public List<User> getAllUsers() {
        return userService.getAllUsers();
    }

    @GetMapping("/{userId}")
    public User getUserById(@PathVariable Long userId) {
        return userService.getUserById(userId);
    }

    @PostMapping
    public User createUser(@RequestBody User user) {
        return userService.createUser(user);
    }

    /*@PutMapping("/{userId}")
    public User updateUser(@PathVariable Long userId, @RequestBody User userDetails) {
        return userService.updateUser(userId, userDetails);
    }*/

    @DeleteMapping("/{userId}")
    public void deleteUser(@PathVariable Long userId) {
        userService.deleteUser(userId);
    }
    @PutMapping ("/{userId}")
    public ResponseEntity<User> updateUser(@RequestBody User user , @PathVariable long userId){
    User user1 = userService.getUserById(userId);
    if (user == null){
    
    return ResponseEntity.notFound().build();
    }
    user1. setLogin (user. getLogin());
    user1. setNom (user.getNom());
    user1. setPrenom (user.getPrenom());
    user1. setCIN (user.getCIN());
    user1. setTEL (user.getTEL());
    user1. setPassword (user.getPassword());
    user1. setFiliere (user.getFiliere());
    user1. setEtablissement (user.getEtablissement());
    user1. setNiveau (user.getNiveau());
    User updatedUser = userService.updateUser(user1);
    return ResponseEntity.ok(updatedUser);}
    @GetMapping("/nombre")
    public long getNombreUtilisateurs() {
        return userService.getNombreUtilisateurs();
    }
   /* @PostMapping("/forgot-password")
    public ResponseEntity<?> forgotPassword(@RequestParam String login) {
        Optional<User> user = userService.findByLogin(login);
        if (user.isPresent()) {
            // Envoyer l'e-mail pour réinitialiser le mot de passe
            // Générer et envoyer le lien avec un token unique
            // Gérer l'envoi de l'e-mail ici
            return ResponseEntity.ok("Un e-mail a été envoyé avec les instructions pour réinitialiser le mot de passe.");
        } else {
            return ResponseEntity.badRequest().body("Aucun utilisateur trouvé avec cet e-mail.");
        }
    }*/
    @GetMapping("/stagiaires")
    public ResponseEntity<List<User>> getStagiaires() {
        List<User> stagiaires = userService.getUsersByRole(RoleType.STAGIAIRE);
        return ResponseEntity.ok(stagiaires);
    }
    @GetMapping("/encadrants")
    public ResponseEntity<List<User>> getEncadrants() {
        List<User> encadrants = userService.getUsersByRole(RoleType.ENCADRANT);
        return ResponseEntity.ok(encadrants);
    }
  
   /* @GetMapping("/by-role")
    public ResponseEntity<Long> getUsersCountByRole(RoleType role) {
        Long count = userService.getUsersCountByRole(role);
        return ResponseEntity.ok(count);
    }*/
    @GetMapping("/count/stagiaire")
    public long getCountOfStagiaireUsers() {
        return userService.getCountOfUsersByRole(RoleType.STAGIAIRE);
    }
    @GetMapping("/count/encadrant")
    public long getCountOfEncadrantUsers() {
        return userService.getCountOfUsersByRole(RoleType.ENCADRANT);
    }
    @GetMapping("/count/stagiaire/{filiere}")
    public long getCountOfStagiaireByFiliere(@PathVariable String filiere) {
        return userService.getCountOfStagiaireByFiliere(filiere);
    }
    /*@GetMapping("/checkEmailExists")
    public ResponseEntity<Boolean> checkEmailExists(@RequestParam String login) {
        boolean exists = userService.isEmailExists(login);
        return ResponseEntity.ok(exists);
    }
    */
    @GetMapping("/checkEmailExists")
    public ResponseEntity<Boolean> checkEmailExists(@RequestParam String login) {
        boolean exists = userService.isEmailExists(login);
        return ResponseEntity.ok(exists);
    }

}
