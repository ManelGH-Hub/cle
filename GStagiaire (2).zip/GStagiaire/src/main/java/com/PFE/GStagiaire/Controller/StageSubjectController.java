package com.PFE.GStagiaire.Controller;

import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.PFE.GStagiaire.Entity.StageSubject;
import com.PFE.GStagiaire.Repository.StageSubjectRepository;
import com.PFE.GStagiaire.Service.SubjectService;
import com.PFE.GStagiaire.exception.ResourceNotFoundException;

import java.util.Date;
import java.util.List;
;
@RestController
@RequestMapping("/api/subjects")
public class StageSubjectController {

    @Autowired
    private StageSubjectRepository subjectRepository;

    @GetMapping("/subjects")
    public List<StageSubject> getAllSubjects() {
        return subjectRepository.findAll();
    }

    @GetMapping("/{id}")
    public ResponseEntity<StageSubject> getSubjectById(@PathVariable Long id) {
        StageSubject subject = subjectRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Subject not found with id: " + id));
        return ResponseEntity.ok(subject);
    }

    @PostMapping("/add")
    public ResponseEntity<StageSubject> createSubject(@RequestBody StageSubject subject) {
        StageSubject createdSubject = subjectRepository.save(subject);
        return ResponseEntity.status(HttpStatus.CREATED).body(createdSubject);
    }

    @PutMapping("/{id}")
    public ResponseEntity<StageSubject> updateSubject(@PathVariable Long id, @RequestBody StageSubject subjectDetails) {
        StageSubject subject = subjectRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Subject not found with id: " + id));

        subject.setTitle(subjectDetails.getTitle());
        subject.setDescription(subjectDetails.getDescription());
        subject.setInternName(subjectDetails.getInternName());
        subject.setSupervisor(subjectDetails.getSupervisor());
        subject.setTeamName(subjectDetails.getTeamName());
        subject.setDd(subjectDetails.getDd());
        subject.setDf(subjectDetails.getDf());
        subject.setDuration(subjectDetails.getDuration());
        // Mettez à jour d'autres champs selon les besoins

        StageSubject updatedSubject = subjectRepository.save(subject);
        return ResponseEntity.ok(updatedSubject);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<?> deleteSubject(@PathVariable Long id) {
        StageSubject subject = subjectRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Subject not found with id: " + id));

        subjectRepository.delete(subject);
        return ResponseEntity.ok().build();
    }
    
    @Autowired
    private SubjectService subjectService;
    @PostMapping("/archive/{id}")
    public ResponseEntity<?> archiveSubject(@PathVariable Long id) {
        StageSubject subject = subjectRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Subject not found with id: " + id));

        subjectService.archiveSubject(subject);
        subjectRepository.delete(subject);
        return ResponseEntity.ok().build();
    }
    
    @GetMapping("/nombre")
    public long getNombreSubject() {
        return subjectService.getNombreSujets();
    }
    @PutMapping("/{id}/updateStatus")
    public ResponseEntity<?> updateStatus(@PathVariable Long id) {
        StageSubject subject = subjectRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Subject not found with id: " + id));

        Date currentDate = new Date();
        if (currentDate.before(subject.getDd())) {
            subject.setStatus("A faire");
        } else if (currentDate.after(subject.getDd()) && currentDate.before(subject.getDf())) {
            subject.setStatus("En cours");
        } else if (currentDate.after(subject.getDf())) {
            subject.setStatus("Terminé");
        }

        subjectRepository.save(subject); // Enregistrer les modifications dans la base de données

        return ResponseEntity.ok().build();
    }
    @GetMapping("/count/termine")
    public Long countSubjectsTermine() {
        return subjectRepository.countByStatus("Terminé");
    }
    @GetMapping("/count/enCours")
    public Long countSubjectsEnCours() {
        return subjectRepository.countByStatus("En cours");
    }
    @GetMapping("/count/aFaire")
    public Long countSubjectsAFaire() {
        return subjectRepository.countByStatus("À faire");
    }
}
    


