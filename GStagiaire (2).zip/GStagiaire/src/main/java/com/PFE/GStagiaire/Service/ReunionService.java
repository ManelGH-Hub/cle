package com.PFE.GStagiaire.Service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.PFE.GStagiaire.Entity.Reunion;
import com.PFE.GStagiaire.Repository.ReunionsRepository;

import java.util.List;
import java.util.Optional;

@Service
public class ReunionService {

    @Autowired
    private ReunionsRepository reunionRepository;

    public Reunion createReunion(Reunion reunion) {
        return reunionRepository.save(reunion);
    }

    public List<Reunion> getAllReunions() {
        return reunionRepository.findAll();
    }

    public Reunion updateReunion(Reunion reunionToUpdate) {
        return reunionRepository.save(reunionToUpdate);
    }

    public Reunion getReunionById(Long id) {
        Optional<Reunion> reunionOptional = reunionRepository.findById(id);
        return reunionOptional.orElse(null);
    }
    //encadrant
    public long countAcceptedReunionsCreatedByEncadrant() {
        return reunionRepository.countByStatusAndCreatedBy("accepté", "ENCADRANT");
    }

    public long countRefusedReunionsCreatedByEncadrant() {
        return reunionRepository.countByStatusAndCreatedBy("refusé", "ENCADRANT");
    }
    public Long countEncoursReunionsCreatedByEncadrant() {
        return reunionRepository.countByStatusAndCreatedBy("En cours","ENCADRANT");
    }
    //stagiaire
    public long countAcceptedReunionsCreatedByStagiaire() {
        return reunionRepository.countByStatusAndCreatedBy("accepté", "STAGIAIRE");
    }

    public long countRefusedReunionsCreatedByStagiaire() {
        return reunionRepository.countByStatusAndCreatedBy("refusé", "STAGIAIRE");
    }
    public long countEncoursReunionsCreatedByStagiaire() {
        return reunionRepository.countByStatusAndCreatedBy("En cours", "STAGIAIRE");
    }
    public void deleteReunion(Long id) {
        reunionRepository.deleteById(id);
    }
    public long countAllReunionsCreatedByStagiaire() {
        return reunionRepository.countByCreatedBy("STAGIAIRE");
    }

    public long countAllReunionsCreatedByEncadrant() {
        return reunionRepository.countByCreatedBy("ENCADRANT");
    }

    public List<Reunion> getReunionsByIdencadrant(Long idEncadrant) {
		// TODO Auto-generated method stub
		return null;
	}

	public List<Reunion> getReunionsByIdstagiaire(Long idStagiaire) {
		// TODO Auto-generated method stub
		return null;
	}

	
}