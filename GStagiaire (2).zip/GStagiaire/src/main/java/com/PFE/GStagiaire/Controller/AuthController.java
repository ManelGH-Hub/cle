package com.PFE.GStagiaire.Controller;

import java.util.Optional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.util.Random;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.PFE.GStagiaire.Entity.User;
import com.PFE.GStagiaire.Repository.UserRepository;
import com.PFE.GStagiaire.Service.AuthService;
import com.PFE.GStagiaire.Service.ImplementationUser;
import com.PFE.GStagiaire.Service.LoginRequest;
import com.PFE.GStagiaire.Service.SUserService;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpSession;

@RestController
public class AuthController {

    @Autowired
    private AuthService authService;

    @PostMapping("/api/login")
    public ResponseEntity<User> login(@RequestBody LoginRequest loginRequest) {
        String login = loginRequest.getlogin();
        String password = loginRequest.getPassword();
        User user = userRepository.findByLogin(login);
        if (user != null && user.getPassword().equals(password)) {
            // Authentification réussie : retournez les informations de l'utilisateur
            return ResponseEntity.ok(user);
        } else {
            // Authentification échouée : retournez une réponse d'erreur
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED).build();
        }
    }



    @GetMapping("/api/logout")
    public String logout(HttpServletRequest request) {
        // Code pour invalider la session de l'utilisateur ou effectuer toute autre action de déconnexion
        // Par exemple, vous pouvez utiliser la méthode invalidate() pour invalider la session :
        request.getSession().invalidate();
        return "Déconnexion réussie";
    }



    @Autowired
    private UserRepository userRepository;

    /*@PutMapping("/api/forgotPassword")
    public ResponseEntity<String> forgotPassword(@RequestParam String login) {
        User user = userRepository.findByLogin(login);
        if (user != null) {
            // Générer un nouveau mot de passe aléatoire
            String newPassword = generateRandomPassword();

            // Enregistrer le nouveau mot de passe dans la base de données
            user.setPassword(newPassword); // Assurez-vous que votre entité User a une propriété password et une méthode setPassword
            userRepository.save(user);

            // Retourner le nouveau mot de passe dans la réponse de l'API
            return new ResponseEntity<>("Mot de passe réinitialisé pour " + login + ". Le nouveau mot de passe est : " + newPassword, HttpStatus.OK);
        } else {
            return new ResponseEntity<>("Utilisateur non trouvé pour le login " + login, HttpStatus.NOT_FOUND);
        }
    }*/
    @Autowired
    private ImplementationUser userService;
    @Autowired
    private SUserService emailService;

    @PostMapping("/forgot-password")
    public ResponseEntity<?> forgotPassword(@RequestBody User request) {
        User user = userService.findByLogin(request.getLogin());
        if (user == null) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body("E-mail invalide");
        }
        String newPassword = generateNewPassword(); // Générez un nouveau mot de passe
        user.setPassword(newPassword);
        userRepository.save(user);

        // Envoyez le nouveau mot de passe par e-mail
        emailService.sendForgotPasswordEmail(user.getLogin(), newPassword);

        return ResponseEntity.ok("Un nouveau mot de passe a été envoyé à votre adresse e-mail.");
    }

    private String generateNewPassword() {
        // Générez un nouveau mot de passe aléatoire ici
        return "NouveauMotDePasse123"; // Exemple, vous devriez utiliser une logique de génération sécurisée
    }
    
}
