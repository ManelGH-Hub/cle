package com.PFE.GStagiaire.Controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import java.util.List;
import com.PFE.GStagiaire.Entity.Archive;
import com.PFE.GStagiaire.Repository.ArchiveRepository;
import com.PFE.GStagiaire.Service.ArchiveService;
import com.PFE.GStagiaire.exception.ResourceNotFoundException;

@RestController
@RequestMapping("/api/archive")
public class ArchiveController {

    @Autowired
    private ArchiveRepository archiveRepository;

    @GetMapping
    public List<Archive> getAllArchivedSubjects() {
        return archiveRepository.findAll();
    }
    
    @DeleteMapping("/{id}")
    public ResponseEntity<?> deleteArchivedSubject(@PathVariable Long id) {
        Archive archivedSubject = archiveRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Archived Subject not found with id: " + id));

        archiveRepository.delete(archivedSubject);

        return ResponseEntity.ok().build();
    }
    @Autowired
    private ArchiveService archiveService;
    @GetMapping("/count")
    public long countArchivedSubjects() {
        return archiveService.countArchivedSubjects();
    }
    @GetMapping("/{id}")
    public ResponseEntity<?> getArchivedSubjectById(@PathVariable Long id) {
        Archive archivedSubject = archiveRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Archived Subject not found with id: " + id));

        return ResponseEntity.ok().body(archivedSubject);
    }

}
