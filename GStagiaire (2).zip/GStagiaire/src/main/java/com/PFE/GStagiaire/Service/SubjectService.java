package com.PFE.GStagiaire.Service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.PFE.GStagiaire.Entity.Archive;
import com.PFE.GStagiaire.Entity.StageSubject;
import com.PFE.GStagiaire.Repository.ArchiveRepository;
import com.PFE.GStagiaire.Repository.StageSubjectRepository;
import com.PFE.GStagiaire.exception.ResourceNotFoundException;
@Service
public class SubjectService {
	  @Autowired
	    private StageSubjectRepository subjectRepository;

	
	    public long getNombreSujets() {
	        return subjectRepository.count();
	    }
		public static StageSubject findById(Long id) {
			// TODO Auto-generated method stub
			return null;
		}
		 @Autowired
		 private ArchiveRepository archiveRepository;
		
		 @Autowired
		private ArchiveService archiveService;
		 public void archiverSujet(Long id) {
		        StageSubject subject = subjectRepository.findById(id)
		                .orElseThrow(() -> new ResourceNotFoundException("Subject not found with id: " + id));

		        // Créer un nouvel objet Archive avec les mêmes valeurs que le sujet
		        Archive archive = new Archive();
		        archive.setTitle(subject.getTitle());
		        archive.setDescription(subject.getDescription());
		        archive.setInternName(subject.getInternName());
		        archive.setTeamName(subject.getTeamName());
		        archive.setSupervisor(subject.getSupervisor());
		        archive.setDuration(subject.getDuration());
		        archive.setStatus(subject.getStatus());

		        // Sauvegarder le sujet dans la base de données des sujets archivés
		        archiveRepository.save(archive); // Utilisation de la méthode save du repository

		        // Supprimer le sujet de la base de données des sujets actifs
		        subjectRepository.delete(subject);
		    }
		
		 public void archiveSubject(StageSubject subject) {
			    // Créer une nouvelle instance d'Archive à partir du sujet archivé
			    Archive archivedSubject = new Archive();
			    archivedSubject.setTitle(subject.getTitle());
			    archivedSubject.setDescription(subject.getDescription());
			    archivedSubject.setInternName(subject.getInternName());
			    archivedSubject.setTeamName(subject.getTeamName());
			    archivedSubject.setSupervisor(subject.getSupervisor());
			    archivedSubject.setDuration(subject.getDuration());
			    archivedSubject.setStatus(subject.getStatus());

			    // Ajouter le sujet archivé à la table Archive
			    archiveRepository.save(archivedSubject);
			}
		


}
