package com.PFE.GStagiaire.Controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.PFE.GStagiaire.Entity.Reunion;
import com.PFE.GStagiaire.Entity.User;
import com.PFE.GStagiaire.Service.ImplementationUser;
import com.PFE.GStagiaire.Service.ReunionService;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/reunions")
public class ReunionController {

    @Autowired
    private ReunionService reunionService;

    @PostMapping("")
    public Reunion createReunion(@RequestBody Reunion reunion) {
        // Assurez-vous que le statut est initialisé à "En cours" si ce n'est pas déjà le cas
        if (reunion.getStatus() == null || reunion.getStatus().isEmpty()) {
            reunion.setStatus("En cours");
        }
        return reunionService.createReunion(reunion);
    }


    @GetMapping("")
    public List<Reunion> getAllReunions() {
        return reunionService.getAllReunions();
    }
    
    @PutMapping("/{id}/update-status")
    public Reunion updateReunionStatus(@PathVariable Long id, @RequestBody String newStatus) {
        Reunion reunionToUpdate = reunionService.getReunionById(id);
        reunionToUpdate.setStatus(newStatus);
        return reunionService.updateReunion(reunionToUpdate);
    }
    // status encadrant 
    @GetMapping("/encadrant/accepted")
    public ResponseEntity<Long> getEncadrantAcceptedReunionCount() {
        long acceptedCount = reunionService.countAcceptedReunionsCreatedByEncadrant();
        return ResponseEntity.ok(acceptedCount);
    }

    @GetMapping("/encadrant/refused")
    public ResponseEntity<Long> getEncadrantRefusedReunionCount() {
        long refusedCount = reunionService.countRefusedReunionsCreatedByEncadrant();
        return ResponseEntity.ok(refusedCount);
    }
    @GetMapping("/encadrant/encours")
    public ResponseEntity<Long> getEncadrantEncoursReunionCount() {
        long encoursCount = reunionService.countEncoursReunionsCreatedByEncadrant();
        return ResponseEntity.ok(encoursCount);
    }
    //status stagiaires 
    @GetMapping("/stagiaire/accepted")
    public ResponseEntity<Long> getStagiaireAcceptedReunionCount() {
        long acceptedCount = reunionService.countAcceptedReunionsCreatedByStagiaire();
        return ResponseEntity.ok(acceptedCount);
    }

    @GetMapping("/stagiaire/refused")
    public ResponseEntity<Long> getStagiaireRefusedReunionCount() {
        long refusedCount = reunionService.countRefusedReunionsCreatedByStagiaire();
        return ResponseEntity.ok(refusedCount);
    }
    @GetMapping("/stagiaire/encours")
    public ResponseEntity<Long> getStagiaireEncoursReunionCount() {
        long encoursCount = reunionService.countEncoursReunionsCreatedByStagiaire();
        return ResponseEntity.ok(encoursCount);
    }
    


    @GetMapping("/encadrant/status")
    public ResponseEntity<Map<String, Long>> getEncadrantReunionStatusCounts() {
        Map<String, Long> statusCounts = new HashMap<>();
        statusCounts.put("accepted", reunionService.countAcceptedReunionsCreatedByEncadrant());
        statusCounts.put("refused", reunionService.countRefusedReunionsCreatedByEncadrant());
        statusCounts.put("En cours", reunionService.countEncoursReunionsCreatedByEncadrant());
        return ResponseEntity.ok(statusCounts);
    }
    @GetMapping("/stagiaire/status")
    public ResponseEntity<Map<String, Long>> getStagiaireReunionStatusCounts() {
        Map<String, Long> statusCounts = new HashMap<>();
        statusCounts.put("accepted", reunionService.countAcceptedReunionsCreatedByStagiaire());
        statusCounts.put("refused", reunionService.countRefusedReunionsCreatedByStagiaire());
        statusCounts.put("En cours", reunionService.countEncoursReunionsCreatedByStagiaire());
        return ResponseEntity.ok(statusCounts);
    }
    @DeleteMapping("/{id}")
    public ResponseEntity<?> deleteReunion(@PathVariable Long id) {
        Reunion reunionToDelete = reunionService.getReunionById(id);
        if (reunionToDelete == null) {
            return ResponseEntity.notFound().build();
        }
        reunionService.deleteReunion(id);
        return ResponseEntity.ok().build();
    }

    @GetMapping("/total-reunions")
    public ResponseEntity<Map<String, Long>> getTotalReunionCounts() {
        Map<String, Long> totalReunionCounts = new HashMap<>();
        long totalStagiaireReunions = reunionService.countAllReunionsCreatedByStagiaire();
        long totalEncadrantReunions = reunionService.countAllReunionsCreatedByEncadrant();
        totalReunionCounts.put("totalStagiaireReunions", totalStagiaireReunions);
        totalReunionCounts.put("totalEncadrantReunions", totalEncadrantReunions);
        return ResponseEntity.ok(totalReunionCounts);
    }
    @GetMapping("/STAGIAIRE")
    public List<User> getSTAGIAIRE() {
        return ImplementationUser.getUsersByRole("STAGIAIRE");
    }
    @GetMapping("/ENCADRANT")
    public List<User> getENCADRANT() {
        return ImplementationUser.getUsersByRole("ENCADRANT");
    }
    
    @GetMapping("/byidencadrant/{idEncadrant}")
    public List<Reunion> getReunionsByIdencadrant(@PathVariable Long idEncadrant) {
        return reunionService.getReunionsByIdencadrant(idEncadrant);
    }

    @GetMapping("/byidstagiaire/{idStagiaire}")
    public List<Reunion> getReunionsByIdstagiaire(@PathVariable Long idStagiaire) {
        return reunionService.getReunionsByIdstagiaire(idStagiaire);
    }
}