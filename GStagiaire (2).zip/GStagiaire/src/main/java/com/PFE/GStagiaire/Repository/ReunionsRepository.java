package com.PFE.GStagiaire.Repository;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.PFE.GStagiaire.Entity.Reunion;

@Repository
public interface ReunionsRepository extends JpaRepository<Reunion, Long> {
	   long countByStatusAndCreatedBy(String status, String createdBy);
	   void deleteById(Long id);
	   long countByCreatedBy(String createdBy);
	   
}

